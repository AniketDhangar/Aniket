import "./App.css";
import AppLayout from "./layout/AppLayout";






function App() {
  return (
    <div>
  
   
      {/* AppLayout handles sidebar for mobile */}
      <AppLayout />
    </div>
  );
}

export default App;
