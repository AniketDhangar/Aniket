export default function Footer() {
  return (
    <footer className="w-full p-4 mb-5 bg-gray-800 dark:bg-gray-800 text-center">
      <p>&copy; {new Date().getFullYear()} My Portfolio. All rights reserved.</p>
    </footer>
  );
}
