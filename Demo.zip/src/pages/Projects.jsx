export default function Projects() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-3xl font-bold">Projects</h1>
      <p>My projects go here.</p>
    </div>
  );
}
