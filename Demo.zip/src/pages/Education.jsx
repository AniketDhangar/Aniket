export default function Education() {
  return (
    <div className="p-6 text-center ">
      <h1 className="text-3xl font-bold">Education</h1>
      <p>My education details go here.</p>
    </div>
  )
}
