import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Core palette
const black = "bg-black";
const navyBlue = "bg-[#0A1A2F]";
const whiteText = "text-white";
const glassNavy = "backdrop-blur-md shadow-xl rounded-lg border border-gray-700/30 bg-[#0A1A2F]/60 hover:bg-[#0A1A2F]/70 transition-all duration-300";

export default function About() {
  // Animation variants for text
  const textVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: { 
      opacity: 1, 
      y: 0, 
      transition: { duration: 0.8, ease: "easeOut" }
    },
  };

  // Animation variants for cards
  const cardVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { 
      opacity: 1, 
      scale: 1, 
      transition: { duration: 0.6, ease: "easeOut" }
    },
  };

  // Sparkle animation variants
  const sparkleVariants = {
    hidden: { opacity: 0, scale: 0 },
    visible: { 
      opacity: [0, 1, 0], 
      scale: [0, 1.5, 0], 
      transition: { duration: 1.5, repeat: Infinity, repeatDelay: 2 }
    },
  };

  // Placeholder education data (replace with your actual details)
  const education = [
    {
      degree: "Bachelor of Technology in Computer Science",
      institution: "XYZ University",
      year: "2018 - 2022",
      description: "Graduated with honors, specializing in software development and web technologies.",
    },
    {
      degree: "High School Diploma",
      institution: "ABC Senior Secondary School",
      year: "2016 - 2018",
      description: "Focused on mathematics and computer science, achieving top grades.",
    },
  ];

  // Placeholder skills data (replace with your actual skills)
  const skills = [
    "React", "Node.js", "Express.js", "MongoDB", "JavaScript", "TypeScript",
    "HTML", "CSS", "Tailwind CSS", "GraphQL", "REST API", "Git",
  ];

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-center p-6 pt-40 bg-gradient-to-br from-black via-[#0A1A2F] to-[#0A1A2F] overflow-hidden">
      {/* Starry Background */}
      <div className="absolute inset-0 z-0">
        <div className="stars animate-twinkle"></div>
        <div className="stars stars2 animate-twinkle2"></div>
        <div className="stars stars3 animate-twinkle3"></div>
      </div>

      {/* Sparkle Effects */}
      <motion.div
        className="absolute top-1/4 left-1/4 w-4 h-4 bg-[#4A90E2] rounded-full"
        variants={sparkleVariants}
        initial="hidden"
        animate="visible"
      />
      <motion.div
        className="absolute bottom-1/4 right-1/4 w-3 h-3 bg-[#4A90E2] rounded-full"
        variants={sparkleVariants}
        initial="hidden"
        animate="visible"
        transition={{ delay: 0.5 }}
      />
      <motion.div
        className="absolute top-1/3 right-1/3 w-5 h-5 bg-[#4A90E2] rounded-full"
        variants={sparkleVariants}
        initial="hidden"
        animate="visible"
        transition={{ delay: 1 }}
      />

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6">
        {/* Introduction */}
        <motion.div
          className="text-center mb-12 sm:mb-16"
          initial="hidden"
          animate="visible"
          variants={textVariants}
        >
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-4 tracking-tight">
            About <span className="text-[#4A90E2]">Me</span>
          </h1>
          <p className="text-base sm:text-lg text-white/80 max-w-2xl mx-auto leading-relaxed">
            I'm Aniket Dhangar, a passionate Full Stack MERN Developer with a knack for building scalable, user-centric web applications. With a strong foundation in both frontend and backend technologies, I thrive on turning ideas into seamless digital experiences that make an impact in the tech universe.
          </p>
        </motion.div>

        {/* Education Section */}
        <motion.div
          className="mb-12 sm:mb-16"
          initial="hidden"
          animate="visible"
          variants={textVariants}
          transition={{ delay: 0.2 }}
        >
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-semibold text-white/90 mb-6 text-center">
            Education
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {education.map((edu, index) => (
              <motion.div
                key={index}
                variants={cardVariants}
                initial="hidden"
                animate="visible"
                transition={{ delay: 0.3 + index * 0.2 }}
              >
                <Card className={`${glassNavy} hover:shadow-[#4A90E2]/50 transition-shadow duration-300`}>
                  <CardHeader>
                    <CardTitle className="text-xl sm:text-2xl text-white">
                      {edu.degree}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-base text-white/80">{edu.institution}</p>
                    <p className="text-sm text-white/60">{edu.year}</p>
                    <p className="text-sm text-white/70 mt-2">{edu.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Skills Section */}
        <motion.div
          initial="hidden"
          animate="visible"
          variants={textVariants}
          transition={{ delay: 0.4 }}
        >
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-semibold text-white/90 mb-6 text-center">
            Skills
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-6">
            {skills.map((skill, index) => (
              <motion.div
                key={index}
                variants={cardVariants}
                initial="hidden"
                animate="visible"
                transition={{ delay: 0.5 + index * 0.1 }}
              >
                <Card className={`${glassNavy} hover:shadow-[#4A90E2]/50 transition-shadow duration-300`}>
                  <CardContent className="p-4 text-center">
                    <p className="text-base sm:text-lg text-white">{skill}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Custom CSS for Starry Background and Animations */}
      <style jsx>{`
        .stars {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: transparent;
          box-shadow: 
            50px 100px #ffffff22,
            150px 300px #ffffff33,
            300px 200px #ffffff22,
            500px 400px #ffffff33,
            700px 150px #ffffff22,
            900px 350px #ffffff33,
            1100px 250px #ffffff22,
            1300px 450px #ffffff33;
        }
        .stars2 {
          box-shadow: 
            100px 200px #ffffff33,
            200px 400px #ffffff22,
            400px 300px #ffffff33,
            600px 500px #ffffff22,
            800px 250px #ffffff33,
            1000px 450px #ffffff22,
            1200px 350px #ffffff33;
        }
        .stars3 {
          box-shadow: 
            75px 150px #ffffff22,
            175px 350px #ffffff33,
            350px 250px #ffffff22,
            550px 450px #ffffff33,
            750px 200px #ffffff22,
            950px 400px #ffffff33,
            1150px 300px #ffffff22;
        }
        .animate-twinkle {
          animation: twinkle 4s infinite;
        }
        .animate-twinkle2 {
          animation: twinkle 5s infinite 1s;
        }
        .animate-twinkle3 {
          animation: twinkle 6s infinite 2s;
        }
        @keyframes twinkle {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
}