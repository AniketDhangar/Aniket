export default function Skills() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-3xl font-bold">Skills</h1>
      <p>My skills go here.</p>
    </div>
  );
}
